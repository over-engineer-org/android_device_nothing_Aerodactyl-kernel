#define LINUX_VERSION_CODE 331743
#define KERNEL_VERSION(a,b,c) (((a) << 16) + ((b) << 8) + ((c) > 255 ? 255 : (c)))
#define LINUX_VERSION_MAJOR 5
#define LINUX_VERSION_PATCHLEVEL 15
#define LINUX_VERSION_SUBLEVEL 223
